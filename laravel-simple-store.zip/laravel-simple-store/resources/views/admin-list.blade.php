@extends('master')

@section('Title', 'list of things')

@section('Content')

    <ul>
        This is list of things
    </ul>

@endsection