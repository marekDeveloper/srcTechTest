@extends('products.layout')

@section('title', 'Products Listing Page')
 
@section('content')
    <div class="row" style="margin: 2rem 0;">
        <div class="col-lg-12">
            <div class="pull-left">
                <h2>Products Listing Page</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('products.create') }}"> Create New Product</a>
                &nbsp; <a class="btn btn-primary" href="/">Home</a>
            </div>
        </div>
    </div>
   
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <table class="table table-bordered">
        <tr>
            <th>#</th>
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Action</th>
        </tr>
        @foreach ($data as $key => $value)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $value->id }}</td>
            <td>{{ $value->name }}</td>
            <td>{{ Str::limit($value->description, 100) }}</td>
            <td>{{ $value->price }}</td>
            <td>
                <form action="{{ route('products.destroy',$value->id) }}" method="POST">
                    <a href="{{ route('products.show', $value->id) }}">Show</a> | 
                    <a href="{{ route('products.edit', $value->id) }}">Edit</a> |    
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>
    {!! $data->links() !!}

    @if(count($dataDeleted)) 
        <br><hr><br>
        <h3>Deleted Records</h3>
        <table class="table table-bordered">
            @foreach ($dataDeleted as $key => $value)
            <tr>
                <td>{{ ++$i }}</td>
                <td>{{ $value->id }}</td>
                <td>{{ $value->name }}</td>
                <td>{{ Str::limit($value->description, 100) }}</td>
                <td>
                    <a href="/products/{{ $value->id }}/restore">Restore Product</a>
                </td>
            </tr>
            @endforeach
        </table>  
    @endif

@endsection