@extends('products.layout')

@section('title', 'Edit Product')
   
@section('content')
    <div class="row" style="margin: 2rem 0;">
        <div class="col-lg-12">
            <div class="pull-left">
                <h2>Edit Product</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('products.index') }}"> Back</a>
            </div>
        </div>
    </div>
   
    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
  
    <form action="{{ route('products.update', $product->id) }}" method="POST">
        @csrf
        @method('PUT')

        <table style="width: 80%; max-width: 700px; border-spacing: 10px; border-collapse: separate;">
        <tr>
            <th style="width: 40%">Product Name: </th>
            <td><input type="text" name="name" class="form-control" placeholder="Enter Product Name" value="{{ $product->name }}"></td>
        </tr>
        <tr>
            <th>Product Description: </th>
            <td><textarea class="form-control" style="height:100px" name="description" placeholder="Enter Description">{{ $product->description }}</textarea></td>
        </tr>
        <tr>
            <th>Price: </th>
            <td><input type="text" name="price" class="form-control" placeholder="Enter Product Price" value="{{ $product->price }}"></td>
        </tr>
        <tr>
            <th>Category: </th>
            <td><input type="text" name="category" class="form-control" placeholder="Enter Product Category" value="{{ $product->category }}"></td>
        </tr>
        <tr>
            <th>Brand: </th>
            <td><input type="text" name="brand" class="form-control" placeholder="Enter Product Brand" value="{{ $product->brand }}"></td>
        </tr>
        <tr>
            <td></td>
            <td><button type="submit" class="btn btn-primary">Submit</button></td>
        </tr>
        </table>

    </form>
@endsection

