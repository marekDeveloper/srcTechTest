@extends('products.layout')

@section('title', 'Show Product')
  
@section('content')
    <div class="row" style="margin: 2rem 0;">
        <div class="col-lg-12">
            <div class="pull-left">
                <h2>Product Detail Page</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('products.index') }}"> Back</a>
            </div>
        </div>
    </div>
   
    <div class="row">
        <div class="col-sm-12">

            <table style="width: 80%; max-width: 700px; border-spacing: 10px; border-collapse: separate; border: 1px solid black;">
            <tr>
                <th style="width: 40%">Product Name: </th>
                <td>{{ $product->name }}</td>
            </tr>
            <tr>
                <th>Product Description: </th>
                <td>{{ $product->description }}</td>
            </tr>
            <tr>
                <th>Price: </th>
                <td>{{ $product->price }}</td>
            </tr>
            <tr>
                <th>Category: </th>
                <td>{{ $product->category }}</td>
            </tr>
            <tr>
                <th>Brand: </th>
                <td>{{ $product->brand }}</td>
            </tr>
            </table>

        </div>
    </div>

    <br><hr><br>

    <div class="row">
        <div class="col-sm-12">
            <h3>Warehouse(s) for this product</h3><br>
        </div>
    </div>

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <form action="/products/{{ $product->id }}/addToWarehouse" method="POST">
    @csrf

    <table style="width: 80%; max-width: 700px; border-spacing: 10px; border-collapse: separate;">
        <tr>
            <th style="width: 40%">Add Product to Warehouse</th>
            <td>
                <select name="warehouse_id" class="form-control">
                    <option value="">Select Warehouse</option>
                    @foreach ($allWarehouses as $item)
                        <option value="{{ $item->id }}">{{ $item->name }}</option>
                    @endforeach 
                </select>
            </td>
        </tr>
        <tr>
            <th>Quantity: </th>
            <td>
                <input type="text" name="quantity" class="form-control" placeholder="Enter Quantity"><br>
            </td>
        </tr>
        <tr>
            <td></td>
            <td>
                <button type="submit" class="btn btn-primary">Submit</button><br>
                <span>If product already exists in selected warehouse, Quantity will be increased by new value.</span>
            </td>
        </tr>
    </table>
   
    </form>
    <br>

    <div class="row">
        <div class="col-sm-12">

            <p>
                Number of warehouses for this product: <b>{{ $product->warehouses()->count() }}</b>
            </p>

            <table class="table table-bordered">
            <tr>
                <th>Warehouse Name</th>
                <th>Quantity</th>
            </tr>

            @foreach ($product->warehouses as $item)
            <tr>
                <td>{{ $item->name }}</td>
                <td>{{ $item->pivot->quantity }}</td>
            </tr>
            @endforeach 
            </table>
            <br><br>

        </div>
    </div>
@endsection


