@extends('warehouses.layout')

@section('title', 'Warehouses Listing Page')
 
@section('content')
    <div class="row" style="margin: 2rem 0;">
        <div class="col-lg-12">
            <div class="pull-left">
                <h2>Warehouses Listing Page</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('warehouses.create') }}"> Create New Warehouse</a>
                &nbsp; <a class="btn btn-primary" href="/">Home</a>
            </div>
        </div>
    </div>
   
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <table class="table table-bordered">
        <tr>
            <th>#</th>
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Action</th>
        </tr>
        @foreach ($data as $key => $value)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $value->id }}</td>
            <td>{{ $value->name }}</td>
            <td>{{ Str::limit($value->description, 100) }}</td>
            <td>
                <a href="{{ route('warehouses.show', $value->id) }}">Show</a>
            </td>
        </tr>
        @endforeach
    </table>
    {!! $data->links() !!}

@endsection