@extends('warehouses.layout')

@section('title', 'Show Warehouse')
  
@section('content')
    <div class="row" style="margin: 2rem 0;">
        <div class="col-lg-12">
            <div class="pull-left">
                <h2>Warehouse Detail Page</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('warehouses.index') }}"> Back</a>
            </div>
        </div>
    </div>
   
    <div class="row">
        <div class="col-sm-12">

            <table style="width: 80%; max-width: 700px; border-spacing: 10px; border-collapse: separate; border: 1px solid black;">
            <tr>
                <th style="width: 40%">Warehouse Name: </th>
                <td>{{ $warehouse->name }}</td>
            </tr>
            <tr>
                <th>Warehouse Description: </th>
                <td>{{ $warehouse->description }}</td>
            </tr>
            <tr>
                <th>Street: </th>
                <td>{{ $warehouse->street }}</td>
            </tr>
            <tr>
                <th>City: </th>
                <td>{{ $warehouse->city }}</td>
            </tr>
            <tr>
                <th>Country: </th>
                <td>{{ $warehouse->country }}</td>
            </tr>
            </table>

        </div>
    </div>

    <br><hr><br>

    <div class="row">
        <div class="col-sm-12">
            <h3>Products for this warehouse</h3><br>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12">

            <p>
                Number of products for this warehouse: <b>{{ $warehouse->products()->count() }}</b><br>
                <b>*</b> Quantity is amount for this warehouse only!
            </p>

            <table class="table table-bordered">
            <tr>
                <th>Product Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Quantity *</th>
            </tr>

            @foreach ($warehouse->products as $item)
            <tr>
                <td>{{ $item->name }}</td>
                <td>{{ $item->description }}</td>
                <td>{{ $item->price }}</td>
                <td>{{ $item->pivot->quantity }}</td>
            </tr>
            @endforeach
            </table>
            <br><br>

        </div>
    </div>

@endsection