@extends('warehouses.layout')

@section('title', 'Add New Warehouse')
  
@section('content')
<div class="row" style="margin: 2rem 0;">
    <div class="col-lg-12">
        <div class="pull-left">
            <h2>Add New Warehouse</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="{{ route('warehouse.index') }}"> Back</a>
        </div>
    </div>
</div>
   
@if ($errors->any())
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
   
<form action="{{ route('warehouses.store') }}" method="POST">
    @csrf

    <table style="width: 80%; max-width: 700px; border-spacing: 10px; border-collapse: separate;">
        <tr>
            <th style="width: 40%">Warehouse Name: </th>
            <td><input type="text" name="name" class="form-control" placeholder="Enter Warehouse Name"></td>
        </tr>
        <tr>
            <th>Warehouse Description: </th>
            <td><textarea class="form-control" style="height:100px" name="description" placeholder="Enter Description"></textarea></td>
        </tr>
        <tr>
            <td></td>
            <td><button type="submit" class="btn btn-primary">Submit</button></td>
        </tr>
    </table>
   
</form>

@endsection

