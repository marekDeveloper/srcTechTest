<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// TO DO! Create/Make reference to Brand model/table
// TO DO! Create/Make this reference to Product Category model/table
// TO DO! Add product attributes: different sizes, colours, etc. OUT OF SCOPE right now
// TO DO! Product image(s). OUT OF SCOPE right now

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('name', 255)->nullable();
            $table->string('description', 500)->nullable();
            $table->decimal('price', 22)->nullable()->default(0.00);
            $table->string('brand', 255)->nullable(); // TO DO! Make this reference to Brand model/table
            $table->string('category', 255)->nullable(); // TO DO! Make this reference to Product Category model/table
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
