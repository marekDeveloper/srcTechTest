<!DOCTYPE html>
<html>
<head>
    <title><?php echo $__env->yieldContent('Title'); ?> | Laravel 8 tests</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
</head>
<body>
  
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    
</body>
</html><?php /**PATH /var/www/html/resources/views/products/layout.blade.php ENDPATH**/ ?>