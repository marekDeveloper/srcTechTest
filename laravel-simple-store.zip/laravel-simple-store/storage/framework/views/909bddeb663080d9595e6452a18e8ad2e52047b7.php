<?php $__env->startSection('title', 'Show Warehouse'); ?>
  
<?php $__env->startSection('content'); ?>
    <div class="row" style="margin: 2rem 0;">
        <div class="col-lg-12">
            <div class="pull-left">
                <h2>Warehouse Detail Page</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('warehouses.index')); ?>"> Back</a>
            </div>
        </div>
    </div>
   
    <div class="row">
        <div class="col-sm-12">

            <table style="width: 80%; max-width: 700px; border-spacing: 10px; border-collapse: separate; border: 1px solid black;">
            <tr>
                <th style="width: 40%">Warehouse Name: </th>
                <td><?php echo e($warehouse->name); ?></td>
            </tr>
            <tr>
                <th>Warehouse Description: </th>
                <td><?php echo e($warehouse->description); ?></td>
            </tr>
            <tr>
                <th>Street: </th>
                <td><?php echo e($warehouse->street); ?></td>
            </tr>
            <tr>
                <th>City: </th>
                <td><?php echo e($warehouse->city); ?></td>
            </tr>
            <tr>
                <th>Country: </th>
                <td><?php echo e($warehouse->country); ?></td>
            </tr>
            </table>

        </div>
    </div>

    <br><hr><br>

    <div class="row">
        <div class="col-sm-12">
            <h3>Products for this warehouse</h3><br>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12">

            <p>
                Number of products for this warehouse: <b><?php echo e($warehouse->products()->count()); ?></b><br>
                <b>*</b> Quantity is amount for this warehouse only!
            </p>

            <table class="table table-bordered">
            <tr>
                <th>Product Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Quantity *</th>
            </tr>

            <?php $__currentLoopData = $warehouse->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->description); ?></td>
                <td><?php echo e($item->price); ?></td>
                <td><?php echo e($item->pivot->quantity); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <br><br>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('warehouses.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/warehouses/show.blade.php ENDPATH**/ ?>