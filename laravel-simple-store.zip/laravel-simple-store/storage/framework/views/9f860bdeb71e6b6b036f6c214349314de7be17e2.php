<?php $__env->startSection('title', 'Show Product'); ?>
  
<?php $__env->startSection('content'); ?>
    <div class="row" style="margin: 2rem 0;">
        <div class="col-lg-12">
            <div class="pull-left">
                <h2>Product Detail Page</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('products.index')); ?>"> Back</a>
            </div>
        </div>
    </div>
   
    <div class="row">
        <div class="col-sm-12">

            <table style="width: 80%; max-width: 700px; border-spacing: 10px; border-collapse: separate; border: 1px solid black;">
            <tr>
                <th style="width: 40%">Product Name: </th>
                <td><?php echo e($product->name); ?></td>
            </tr>
            <tr>
                <th>Product Description: </th>
                <td><?php echo e($product->description); ?></td>
            </tr>
            <tr>
                <th>Price: </th>
                <td><?php echo e($product->price); ?></td>
            </tr>
            <tr>
                <th>Category: </th>
                <td><?php echo e($product->category); ?></td>
            </tr>
            <tr>
                <th>Brand: </th>
                <td><?php echo e($product->brand); ?></td>
            </tr>
            </table>

        </div>
    </div>

    <br><hr><br>

    <div class="row">
        <div class="col-sm-12">
            <h3>Warehouse(s) for this product</h3><br>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <form action="/products/<?php echo e($product->id); ?>/addToWarehouse" method="POST">
    <?php echo csrf_field(); ?>

    <table style="width: 80%; max-width: 700px; border-spacing: 10px; border-collapse: separate;">
        <tr>
            <th style="width: 40%">Add Product to Warehouse</th>
            <td>
                <select name="warehouse_id" class="form-control">
                    <option value="">Select Warehouse</option>
                    <?php $__currentLoopData = $allWarehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </select>
            </td>
        </tr>
        <tr>
            <th>Quantity: </th>
            <td>
                <input type="text" name="quantity" class="form-control" placeholder="Enter Quantity"><br>
            </td>
        </tr>
        <tr>
            <td></td>
            <td>
                <button type="submit" class="btn btn-primary">Submit</button><br>
                <span>If product already exists in selected warehouse, Quantity will be increased by new value.</span>
            </td>
        </tr>
    </table>
   
    </form>
    <br>

    <div class="row">
        <div class="col-sm-12">

            <p>
                Number of warehouses for this product: <b><?php echo e($product->warehouses()->count()); ?></b>
            </p>

            <table class="table table-bordered">
            <tr>
                <th>Warehouse Name</th>
                <th>Quantity</th>
            </tr>

            <?php $__currentLoopData = $product->warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->pivot->quantity); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </table>
            <br><br>

        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('products.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/products/show.blade.php ENDPATH**/ ?>