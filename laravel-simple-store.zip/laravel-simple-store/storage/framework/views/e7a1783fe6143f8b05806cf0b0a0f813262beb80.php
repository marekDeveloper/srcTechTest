<?php $__env->startSection('title', 'Edit Product'); ?>
   
<?php $__env->startSection('content'); ?>
    <div class="row" style="margin: 2rem 0;">
        <div class="col-lg-12">
            <div class="pull-left">
                <h2>Edit Product</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('products.index')); ?>"> Back</a>
            </div>
        </div>
    </div>
   
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
  
    <form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <table style="width: 80%; max-width: 700px; border-spacing: 10px; border-collapse: separate;">
        <tr>
            <th style="width: 40%">Product Name: </th>
            <td><input type="text" name="name" class="form-control" placeholder="Enter Product Name" value="<?php echo e($product->name); ?>"></td>
        </tr>
        <tr>
            <th>Product Description: </th>
            <td><textarea class="form-control" style="height:100px" name="description" placeholder="Enter Description"><?php echo e($product->description); ?></textarea></td>
        </tr>
        <tr>
            <th>Price: </th>
            <td><input type="text" name="price" class="form-control" placeholder="Enter Product Price" value="<?php echo e($product->price); ?>"></td>
        </tr>
        <tr>
            <th>Category: </th>
            <td><input type="text" name="category" class="form-control" placeholder="Enter Product Category" value="<?php echo e($product->category); ?>"></td>
        </tr>
        <tr>
            <th>Brand: </th>
            <td><input type="text" name="brand" class="form-control" placeholder="Enter Product Brand" value="<?php echo e($product->brand); ?>"></td>
        </tr>
        <tr>
            <td></td>
            <td><button type="submit" class="btn btn-primary">Submit</button></td>
        </tr>
        </table>

    </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('products.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/products/edit.blade.php ENDPATH**/ ?>