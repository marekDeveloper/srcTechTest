<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Warehouse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // show list of active products
        $data = Product::latest()->paginate(25);

        // show list of trashed / soft deleted products
        $dataDeleted = Product::onlyTrashed()->get();

        return view('products.index',compact('data', 'dataDeleted'))
            ->with('i', (request()->input('page', 1) - 1) * 25);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // show form to create new product
        return view('products.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // required fields name, description, price, ... other field optional
        $request->validate([
            'name'=>'required',
            'description'=>'required',
            'price'=>'required|numeric|gt:0'
        ]); 

        // create new product
        $product = new Product([
            'name' => $request->get('name'),
            'description' => $request->get('description'),
            'price' => $request->get('price'),
            'brand' => $request->get('brand'),            
            'category' => $request->get('category')
        ]);

        // save product
        $product->save();

        // redirect to products page
        return redirect('/products')->with('success', 'New product saved!');
    }

    /**
     * Display the specified resource.
     *
     * @param  Product $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        // show product detail page
        $allWarehouses = Warehouse::orderBy('Name')->get();
        return view('products.show', compact('product', 'allWarehouses'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  Product $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        // Show form to edit product
        return view('products.edit',compact('product'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  Product $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        // required fields name, description, price, ... other field optional
        $request->validate([
            'name'=>'required',
            'description'=>'required',
            'price'=>'required|numeric|gt:0'
        ]);

        // Update product and redirect to list page
        $product->update($request->all());
    
        return redirect()->route('products.index')
                        ->with('success','Product updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Product $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        // soft delete product
        $product->delete();

        // TO DO! Use some mailer service here?
        mail('mpi_sk@hotmail.com', 'Product deleted.', 'Message: Product ID ' . $product->id . ' deleted.');
    
        return redirect()->route('products.index')
                        ->with('success','Product deleted successfully');
    }

    /**
     * Restore soft deleted the specified resource.
     *
     * @param  int $productId
     * @return \Illuminate\Http\Response
     */
    public function restore(int $productId)
    {
        $product = Product::withTrashed()->find($productId)->restore();

        return redirect()->route('products.index')
                        ->with('success','Product restored successfully');
    }

    public function addToWarehouse(Request $request, int $productId)
    {
        $product = Product::findOrFail($productId);

        $validator = Validator::make($request->all(), [
            'warehouse_id'=>'required|numeric|gt:0',
            'quantity'=>'required|numeric|gt:0'
        ]);

        $warehouseId = $request->post('warehouse_id');
        $quantity = $request->post('quantity');

        // Check for validation failure
        if ($validator->fails()) {

            print 'DATA INPUT VALIDATION ERROR!!!<BR>';
            print 'TO DO! Show better message!<BR>';
            print_r($request->post());

        } else {

            // all is good, let's import relationship
            // well, we need to check if this record is not already created in DB
            // if product & warehouse relationship already exists we only need to update quantity
            // TO DO! To review if we update quantity ... add values together or use this tool as override?!?

            // check for existing relationship
            if ($product->warehouses->contains($warehouseId)) {

                // we do have existing relationship, get that warehouse
                $warehouse = $product->warehouses->find($warehouseId);

                // get quantity form pivot table
                $oldQuantity = $warehouse->pivot->quantity;

                // update new quantity value as sum of old and new
                $quantity+= $oldQuantity;

                // update existing 
                $product->warehouses()->updateExistingPivot($warehouseId,['quantity' => $quantity]);
                $messageAction = 'updated for';

            } else {

                // create new relationship
                $product->warehouses()->attach($warehouseId,['quantity' => $quantity]);
                $messageAction = 'added into';

            } // end if

            return redirect()->route('products.show', $product->id)
                        ->with('success','Product successfully ' . $messageAction . ' the Warehouse');
        }
    }

    /**************************
     * API Methods
     **************************/
    // TO DO! Split to separate file API controller?

    // Return product detail by ID - only detail of product, NO warehouses right now
    public function apiDetail(int $id)
    {
        $product = Product::findOrFail($id);

        return $product;
    }

    // Create/Store new product
    public function apiCreate(Request $request)
    {
        // required fields name, description, price, ... other field optional
        $request->validate([
            'name'=>'required',
            'description'=>'required',
            'price'=>'required|numeric|gt:0'
        ]);

        try {

            // create new product
            $product = new Product([
                'name' => $request->get('name'),
                'description' => $request->get('description'),
                'price' => $request->get('price'),
                'brand' => $request->get('brand'),            
                'category' => $request->get('category')
            ]);

            // save product
            $product->save();

        } catch (\Exception $e) {

            // Return Json Response
            return response()->json([
                'message' => 'Something went wrong!'
            ],500);
        }

        // Return Json Response
        return response()->json([
            'message' => 'Product successfully created.'
        ], 200);

    }

    // Update product
    public function apiUpdate(Request $request, int $id)
    {
        $product = Product::findOrFail($id);

        // required fields name, description, price, ... other field optional
        $request->validate([
            'name'=>'required',
            'description'=>'required',
            'price'=>'required|numeric|gt:0'
        ]);

        // Update product
        $product->update($request->all());

        // Return Json Response
        return response()->json([
            'message' => 'Product successfully updated.'
        ], 200);
    }

    // Delete product
    public function apiDelete(int $id)
    {
        $product = Product::findOrFail($id);

        // soft delete product
        $product->delete();

        // Return Json Response
        return response()->json([
            'message' => 'Product deleted.'
        ], 200);
    }
}
