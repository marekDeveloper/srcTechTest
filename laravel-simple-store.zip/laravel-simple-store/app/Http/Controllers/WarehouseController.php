<?php

namespace App\Http\Controllers;

use App\Models\Warehouse;
use Illuminate\Http\Request;

class WarehouseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Warehouse::latest()->paginate(5);
        
        return view('warehouses.index',compact('data'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        print 'TO DO! Create Warehouse';
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        print 'TO DO! Store Warehouse';
    }

    /**
     * Display the specified resource.
     *
     * @param  Warehouse $warehouse
     * @return \Illuminate\Http\Response
     */
    public function show(Warehouse $warehouse)
    {
        // show warehouse detail page
        return view('warehouses.show',compact('warehouse'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  Product $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Warehouse $warehouse)
    {
        print 'TO DO! Edit Warehouse';
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  Product $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Warehouse $warehouse)
    {
        print 'TO DO! Update Warehouse';
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Product $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Warehouse $warehouse)
    {
        print 'TO DO! Delete Warehouse';
    }

    public function importTestData()
    {
        // TO DO! Review if this would be better as import from CSV file
        // TO DO! Review if there are tools to import random data, maybe seeder?
        // define few test/sample warehouse data
        $testData = [];
        $testData[] = [
            'Warehouse #11',
            'Newest & largest warehouse located in beautiful Central Slovakia',
            'Skuteckeho 1',
            'Banska Bystrica',
            'Slovakia'
        ];
        $testData[] = [
            'Blue Warehouse',
            'Small blue warehouse in Bratislava',
            'Vajnorska 321',
            'Bratislava',
            'Slovakia'
        ];
        $testData[] = [
            'Czech Central Main',
            'One of older places in our network in Prague',
            'Bratislavska 45',
            'Prague',
            'Czechia'
        ];
        $testData[] = [
            'Warehouse #4',
            'Just test for pagination, Warehouse #4',
            'Street Test 123',
            'City Test',
            'Country Test'
        ];
        $testData[] = [
            'Warehouse #5',
            'Just test for pagination, Warehouse #5',
            'Street Test 123',
            'City Test',
            'Country Test'
        ];
        $testData[] = [
            'Warehouse #6',
            'Just test for pagination, Warehouse #6. Should show on the second page. When 5 per page',
            'Street Test 123',
            'City Test',
            'Country Test'
        ];

        // first test if DB table is empty = no records, import only once
        $count = Warehouse::get()->count();

        print 'Importing test Warehouse records. <br><br>';
        print 'Number of Warehouse records in DB: ' . $count . '. <br><br>';

        if ($count > 0) {

            print 'ERROR: Warehouse DB table is not empty! You can run this only once! <br><br>';

        } else {

            print 'DB table empty, start importing test data. <br>';

            foreach ($testData as $item) {

                $warehouse = new Warehouse([
                    'name' => $item[0],
                    'description' => $item[1],
                    'street' => $item[2],
                    'city' => $item[3],
                    'country' => $item[4]
                ]);

                $warehouse->save();

                print 'Created warehouse record: ' . $item[0] . '.<br>';

            } // end foreach

            $count = Warehouse::get()->count();
            print 'IMPORTED: Number of Warehouse records in DB: ' . $count . '. <br><br>';

        } // end if

        print 'Warehouse test data import FINISHED! <br><br>';
        exit();
    }

    /**************************
     * API Methods
     **************************/
    // TO DO! Split to separate file API controller?

    // Return list of all warehouses
    public function apiIndex() {

        // return all warehouses without pagination
        //return Warehouse::all();

        // return warehouses, with pagination, 5 per page
        // TO DO! To test and review this is actually that simple
        return Warehouse::paginate(5);
    }

    // Return warehouse detail by ID + list of products in this warehouse
    public function apiDetail(int $id) {

        $warehouse = Warehouse::findOrFail($id);

        if ($warehouse) {
            $warehouse['products'] = $warehouse->products;
        }

        return $warehouse;
    }
    
}
